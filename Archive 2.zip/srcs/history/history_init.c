#include "history.h"

t_hist	*singleton_hist(void)
{
	static t_hist	h;

	return (&h);
}

void	history_init(t_hist *h)
{
	h->cur = NULL;
}
