#ifndef OPTION_H
# define OPTION_H

typedef enum
{
	ALLEXPORT = 1,
	INTERACTIVE = 2,
}	t_option_id;

#endif
