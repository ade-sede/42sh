#ifndef MY_SIGNAL_H
# define MY_SIGNAL_H

# include <signal.h>

void		all_signal_ign(void);
void		all_signal_dfl(void);

#endif
