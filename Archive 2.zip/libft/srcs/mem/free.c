#include "libft.h"

void	ft_free(void *p)
{
	free(p);
}
