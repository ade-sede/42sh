#include "line_editing.h"

void	nothing(int signum)
{
	(void)signum;
}

void	no_handle_signals(void)
{
	signal(SIGINT, nothing);
}
