#include "libft.h"

void		ft_memlcat(char *big, char *little, int start, int size)
{
}
